package fragment.submissions.bean;

/**
 * 
 * @author maxp
 *
 */
public class VariationOf2 {
	private int i1;
	private int i2;

	/**
	 * 
	 * @param i1
	 * @param i2
	 */
	public VariationOf2(final int i1, final int i2) {
		super();
		this.i1 = i1;
		this.i2 = i2;
	}

	public int getI1() {
		return i1;
	}

	public void setI1(int i1) {
		this.i1 = i1;
	}

	public int getI2() {
		return i2;
	}

	public void setI2(int i2) {
		this.i2 = i2;
	}
}
