package fragment.submissions.error;

/**
 * 
 * @author maxp
 *
 */
public class ReassembleException extends RuntimeException {

	/***
	 * 
	 * @param message
	 */
	public ReassembleException(String message){
        super(message);
    }
}
