package fragment.submissions.error;


/***
 * 
 * @author maxp
 *
 */
public class IllegalFragmentException extends IllegalArgumentException {
	/***
	 * 
	 * @param message
	 */
	public IllegalFragmentException(String message){
        super(message);
    }
}
